from models import Person, Student, Teacher, Staff, Principal, StudentTeacher

people = []

def create_person():
    print("\n--- Create a New Person ---")
    print("1. Student")
    print("2. Teacher")
    print("3. Staff")
    print("4. Principal")
    print("5. StudentTeacher")

    choice = input("Enter type (1-5): ")

    name = input("Enter name: ")
    age = int(input("Enter age: "))

    if choice == "1":
        student_id = input("Enter student ID: ")
        grade = input("Enter grade: ")
        person = Student(name, age, student_id, grade)

    elif choice == "2":
        subject = input("Enter subject: ")
        person = Teacher(name, age, subject)

    elif choice == "3":
        position = input("Enter position: ")
        person = Staff(name, age, position)

    elif choice == "4":
        subject = input("Enter subject specialization: ")
        years = int(input("Enter years of experience: "))
        person = Principal(name, age, subject, years)

    elif choice == "5":
        student_id = input("Enter student ID: ")
        grade = input("Enter grade: ")
        subject = input("Enter subject teaching: ")
        person = StudentTeacher(name, age, student_id, grade, subject)

    else:
        print("Invalid choice!")
        return

    people.append(person)
    print(f"{person.__class__.__name__} added successfully!")

def list_people():
    print("\n--- List of People ---")
    if not people:
        print("No people found.")
    else:
        for i, person in enumerate(people, 1):
            print(f"{i}. {person}")

def update_person():
    list_people()
    if not people:
        return

    try:
        index = int(input("Enter number to update: ")) - 1
        if 0 <= index < len(people):
            person = people[index]
            print(f"Updating {person.name} ({person.__class__.__name__})")

            new_name = input("Enter new name (or press Enter to keep current): ")
            if new_name:
                person.name = new_name

            try:
                new_age = input("Enter new age (or press Enter to keep current): ")
                if new_age:
                    person.age = int(new_age)
            except ValueError:
                print("Invalid age; keeping previous value.")

            print("Record updated successfully.")
        else:
            print("Invalid number.")
    except ValueError:
        print("Invalid input.")

def delete_person():
    list_people()
    if not people:
        return

    try:
        index = int(input("Enter number to delete: ")) - 1
        if 0 <= index < len(people):
            confirm = input(f"Are you sure you want to delete {people[index].name}? (y/n): ").lower()
            if confirm == "y":
                deleted = people.pop(index)
                print(f"{deleted.name} has been removed.")
            else:
                print("Deletion cancelled.")
        else:
            print("Invalid number.")
    except ValueError:
        print("Invalid input.")

def show_detailed_info():
    print("\n--- Show Detailed Info ---")
    if not people:
        print("No people found.")
        return

    for person in people:
        print("\n--------------------")
        person.display_info()  

def main_menu():
    while True:
        print("\n==== Academic Management Mini-System ====")
        print("1. Create Person")
        print("2. List People")
        print("3. Update Person")
        print("4. Delete Person")
        print("5. Show Detailed Info")
        print("0. Exit")

        choice = input("Enter choice: ")

        if choice == "1":
            create_person()
        elif choice == "2":
            list_people()
        elif choice == "3":
            update_person()
        elif choice == "4":
            delete_person()
        elif choice == "5":
            show_detailed_info()
        elif choice == "0":
            print("Exiting system... Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main_menu()
