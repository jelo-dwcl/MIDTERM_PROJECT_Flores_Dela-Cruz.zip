from student import Student
from teacher import Teacher

class StudentTeacher(Student, Teacher):

    def __init__(self, name: str, age: int, student_id: str, grade: str, subject: str):
        Student.__init__(self, name, age, student_id, grade)
        Teacher.__init__(self, name, age, subject)

    def display_info(self):
        print("--- Student Teacher Info ---")
        print(f"Name: {self.name}")
        print(f"Age: {self.age}")
        print(f"Student ID: {self.student_id}")
        print(f"Grade: {self.grade}")
        print(f"Subject Teaching: {self.subject}")