from person import Person

class Student(Person):

    def __init__(self, name: str, age: int, student_id: str, grade: str):
        super().__init__(name, age)
        self.student_id = student_id
        self.grade = grade

    def display_info(self):
        super().display_info()
        print(f"Student ID: {self.student_id}")
        print(f"Grade: {self.grade}")