from person import Person

class Staff(Person):

    def __init__(self, name: str, age: int, position: str):
        super().__init__(name, age)
        self.position = position

    def display_info(self):
        super().display_info()
        print(f"Position: {self.position}")