class Person:
 
    def __init__(self, name: str, age: int):
        self.name = name
        self.age = age

    def display_info(self):
        print(f"Name: {self.name}")
        print(f"Age: {self.age}")

    def __str__(self):
        return f"{self.__class__.__name__} - {self.name}, Age: {self.age}"