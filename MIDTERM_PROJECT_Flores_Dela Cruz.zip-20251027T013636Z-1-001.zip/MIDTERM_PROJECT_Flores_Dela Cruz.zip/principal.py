from teacher import Teacher

class Principal(Teacher):

    def __init__(self, name: str, age: int, subject: str, years_of_experience: int):
        super().__init__(name, age, subject)
        self.years_of_experience = years_of_experience

    def display_info(self):
        super().display_info()
        print(f"Years of Experience: {self.years_of_experience}")
        print("Role: Principal")